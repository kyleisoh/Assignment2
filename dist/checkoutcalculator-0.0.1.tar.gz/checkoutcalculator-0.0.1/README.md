# Deliverable2
A simple checkout calculator built for CSC301 Deliverable 2

### App Presentation
(Web Desktop)[LINK HERE]

### App Usage Guidelines
#### Use Cases
1) Adding items
2) Removing items
3) Applying discounts
4) Adding taxes

### Web Application Local Development

### Web Application CI/CD

#### Web-CI
#### Deploy-Staging
#### Deploy-Production